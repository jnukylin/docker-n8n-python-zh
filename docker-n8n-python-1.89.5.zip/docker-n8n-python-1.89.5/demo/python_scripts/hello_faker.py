from faker import Faker

if __name__ == '__main__':
    fake = Faker()
    print(fake.name())
    exit(0)
