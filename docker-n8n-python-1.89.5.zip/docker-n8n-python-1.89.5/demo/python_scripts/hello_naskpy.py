from naskpy.main import hello_world

if __name__ == '__main__':
    print(hello_world())
    exit(0)
